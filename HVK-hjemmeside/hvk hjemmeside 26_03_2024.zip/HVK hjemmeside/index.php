<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Dad's Firm</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <!-- Navigation bar if needed -->
    </header>

    <main>
        <section class="hero">
            <!-- Hero section with pictures and text -->
        </section>

        <section class="content">
            <!-- Main content section with more information -->
        </section>

        <section class="contact">
            <!-- Contact form section -->
            <h2>Contact Us</h2>
            <form id="contact-form">
                <input type="text" name="name" placeholder="Your Name" required>
                <input type="email" name="email" placeholder="Your Email" required>
                <textarea name="message" placeholder="Your Message" rows="4" required></textarea>
                <button type="submit">Send Message</button>




            </form>
        </section>
    </main>

    <footer>
    <?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $message = $_POST['message'];
    
    $to = 'andersknudsen98@gmail.com';
    $subject = 'Message from your website';
    $headers = "From: $name <$email>";
    $body = "Name: $name\nEmail: $email\n\n$message";
    
    if (mail($to, $subject, $body, $headers)) {
        echo 'Message sent successfully!';
    } else {
        echo 'There was a problem sending your message.';
    }
}
?>
    </footer>

    <script src="script.js"></script>
</body>



</html>
