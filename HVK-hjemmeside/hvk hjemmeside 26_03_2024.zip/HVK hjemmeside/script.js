document.getElementById('contact-form').addEventListener('submit', function(event) {
    event.preventDefault();
    // Your code to send the message via email
});